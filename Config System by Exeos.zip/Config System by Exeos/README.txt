    
       Made by Exeos#3002
       you are allowed to use this config system
       but you have to credit me
     
       @author Exeos
    